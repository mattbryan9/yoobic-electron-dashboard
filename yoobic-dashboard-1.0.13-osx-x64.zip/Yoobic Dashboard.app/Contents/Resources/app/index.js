'use strict';

var express = require('express');
var enforce = require('express-sslify');
var compression = require('compression');

var app = express();
if (process.env.FORCE_SSL === 'true') {
    app.use(enforce.HTTPS({ // eslint-disable-line new-cap
        trustProtoHeader: true
    }));
}

let excluded = ['/index.js', '/.gitignore', '/package.json', '/Procfile'];
app.use('*', function(req, res, next) {
    if (excluded.indexOf(req.baseUrl) >= 0) {
        res.end();
    } else {
        next();
    }
});
app.use(compression());
app.use(express.static('.'));
app.listen(process.env.PORT || 3001);
